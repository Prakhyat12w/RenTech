"""
URL configuration for RentTech project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from home.views import *
from django.conf.urls.static import static
from django.conf import settings
from debug_toolbar.toolbar import debug_toolbar_urls

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),
    path('login/', login_page, name='login_page'),
    path('logout/', logout_page, name='logout_page'),
    path('home/', home_page, name='home_page'),
    path('phones/', phones, name='phones'),
    path('buy/smartwatch/<slug:smartwatch_slug>/', buy_smartwatch, name='buy_smartwatch'),
    path('buy/phone/<str:phone_slug>/', buy_phone, name='buy_phone'),
    path('buy/laptop/<str:laptop_slug>/', buy_laptop, name='buy_laptop'),
    path('laptops/', laptops, name='laptops'),
    path('smartwatches/', smartwatches, name='smartwatches'),
    path('register/', register, name='register_page'),
    path('rent/phone/<str:phone_slug>/', rent_phone, name="rent_phone"),
    path('rent/laptop/<str:laptop_slug>/', rent_laptop, name="rent_laptop"),
    path('whyrent/', whyrent, name='whyrent'),
    path('user/', user_profile, name='user_profile'),
    path('disclaimer/', disclaimer, name='disclaimer'),
    path('checkout/laptop/<str:laptop_slug>/', checkout_laptop, name='checkout_laptop'),
    path('checkout/phone/<str:phone_slug>/', checkout_phone, name='checkout_phone'),
    path('checkout/smartwatch/<str:smartwatch_slug>/', checkout_smartwatch, name='checkout_smartwatch'),
    path('terms-and-conditions', terms_and_conditions, name='terms_and_conditions'),
    path('payment/phone/<str:phone_slug>/', payment_phone, name='payment_phone'),
    path('payment/laptop/<str:laptop_slug>/', payment_laptop, name='payment_laptop'),
    path('payment/smartwatch/<str:smartwatch_slug>/', payment_smartwatch, name='payment_smartwatch'),
    path('payrent/laptop/<str:laptop_slug>/', payrent_laptop, name='payrent_laptop'),
    path('payrent/phone/<str:phone_slug>/', payrent_phone, name = "payrent_phone"),
    path('about/', about, name = "about"),
    path("feedback/", feedback_view, name="feedback"),
    
    
    
    
    
    



] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) + \
    debug_toolbar_urls()
