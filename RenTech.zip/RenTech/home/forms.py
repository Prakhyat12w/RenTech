from django import forms


class FeedbackForm(forms.Form):
    experience_rating = forms.IntegerField(required=False, min_value=1, max_value=10)
    experience_text = forms.CharField(required=False, max_length=500, widget=forms.Textarea)
    bug_report = forms.ChoiceField(choices=[("No", "No"), ("Yes", "Yes")], widget=forms.Select)
    bug_details = forms.CharField(required=False, max_length=1000, widget=forms.Textarea)
    theme_rating = forms.IntegerField(required=False, min_value=1, max_value=10)
    theme_text = forms.CharField(required=False, max_length=500, widget=forms.Textarea)
    ideas = forms.CharField(required=False, max_length=2000, widget=forms.Textarea)
