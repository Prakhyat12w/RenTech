from django.db import models
from tabnanny import verbose
from tkinter import CASCADE
from django.db import models
from django.contrib.auth.models import User
from django.utils.text import slugify

# Create your models here.


class Device(models.Model):
    CATEGORY_CHOICES = [
        ('phone', 'Phone'),
        ('laptop', 'Laptop'),
        ('smartwatch', 'Smartwatch'),
    ]
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    name = models.CharField(max_length=100)
    brand = models.CharField(max_length=100)
    slug = models.SlugField(unique=True, blank=True)
    description = models.TextField()
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    image = models.ImageField(upload_to="devices")
    image2 = models.ImageField(upload_to="devices", null=True, blank=True)
    video = models.ImageField(upload_to="devices",  null=True, blank=True) 
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    daily_rent_price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    features = models.TextField(default="")

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)  
        super().save(*args, **kwargs)

    def get_features_list(self):
        return self.features.split(",") if self.features else []

    def __str__(self):
        return f"{self.category.capitalize()} - {self.name}"


class Order(models.Model):
    ORDER_TYPES = [
        ('rent', 'Rent'),
        ('buy', 'Buy'),
    ]

    ORDER_STATUS = [
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('canceled', 'Canceled'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    device = models.ForeignKey(Device, on_delete=models.CASCADE)
    order_type = models.CharField(max_length=20, choices=ORDER_TYPES)
    order_date = models.DateTimeField(auto_now_add=True)
    rent_start_date = models.DateTimeField(null=True, blank=True)
    rent_end_date = models.DateTimeField(null=True, blank=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, choices=ORDER_STATUS, default='pending')

    def __str__(self):
        return f"Order for {self.device.name} by {self.user.username}"


class Payment(models.Model):
    PAYMENT_METHODS = [
        ('credit_card', 'Credit Card'),
        ('paypal', 'PayPal'),
        ('Paytm', 'PAYTM'),
        ('GooglePay', 'Google Pay'),
        ('bank_transfer', 'Bank Transfer'),
    ]

    PAYMENT_STATUS = [
        ('pending', 'Pending'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
    ]

    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    payment_date = models.DateTimeField(auto_now_add=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHODS)
    status = models.CharField(max_length=20, choices=PAYMENT_STATUS, default='pending')

    def __str__(self):
        return f"Payment for {self.order.device.name} by {self.user.username}"


class Review(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    device = models.ForeignKey(Device, on_delete=models.CASCADE)
    rating = models.IntegerField(choices=[(1, '1 Star'), (2, '2 Stars'), (3, '3 Stars'), (4, '4 Stars'), (5, '5 Stars')])
    review_text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Review for {self.device.name} by {self.user.username} - {self.rating} Stars"


class RentalHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    device = models.ForeignKey(Device, on_delete=models.CASCADE)
    rent_start_date = models.DateTimeField()
    rent_end_date = models.DateTimeField()
    rental_status = models.CharField(max_length=20, choices=[('active', 'Active'), ('completed', 'Completed'), ('canceled', 'Canceled')])

    def __str__(self):
        return f"Rental History - {self.user.username} - {self.device.name}"


class ShippingAddress(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    address_line_1 = models.CharField(max_length=255)
    address_line_2 = models.CharField(max_length=255, null=True, blank=True)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    zip_code = models.CharField(max_length=20)
    country = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=20)

    def __str__(self):
        return f"Shipping Address for {self.user.username}"


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=15, blank=True, null=True)

    def __str__(self):
        return self.user.username
