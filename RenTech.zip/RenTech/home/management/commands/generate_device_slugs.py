from django.core.management.base import BaseCommand
from django.utils.text import slugify
from home.models import Device


class Command(BaseCommand):
    help = 'Generates slugs for existing devices'

    def handle(self, *args, **kwargs):
        devices = Device.objects.all()
        for device in devices:
            if not device.slug:
                device.slug = slugify(device.name)
                device.save()
                self.stdout.write(self.style.SUCCESS(f'Successfully generated slug for {device.name}'))
