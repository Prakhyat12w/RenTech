from multiprocessing import context
from django.shortcuts import render, redirect, get_object_or_404
from .models import Device, Profile
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from django.contrib.auth.hashers import check_password
import logging
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.http import JsonResponse
from django.core.mail import send_mail
from .forms import FeedbackForm


# Set up logging
logger = logging.getLogger(__name__)


def home(request):
    return redirect('/login/')


def home_page(request):
    return render(request, 'home.html', context={'page': "RenTech"})


def login_page(request):
    if request.user.is_authenticated:
        return redirect('/home/')
    if request.method == "POST":
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()
        if not username or not password:
            messages.info(request, "All fields are required.")
            return redirect('/login/')
        if not User.objects.filter(username=username).exists():
            messages.info(request, "Invalid Username.")
            return redirect('/login/')
        user = authenticate(username=username, password=password)
        if user is None:
            messages.info(request, "Invalid Password.")
            return redirect('/login/')
        login(request, user)
        return redirect('/home/')
    return render(request, 'login.html')


def register(request):
    if request.user.is_authenticated:
        return redirect('/home/')
    if request.method == "POST":
        first_name = request.POST.get('first_name', '').strip()
        last_name = request.POST.get('last_name', '').strip()
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()
        errors = []
        if not all([first_name, last_name, username, password]):
            errors.append("All fields are required.")
        if User.objects.filter(username=username).exists():
            errors.append("Username already taken.")
        if errors:
            return render(request, 'register.html', {'errors': errors})
        User.objects.create_user(
            first_name=first_name,
            last_name=last_name,
            username=username,
            password=password
        )
        messages.success(request, "Account created successfully.")
        return redirect('/login/')          
    return render(request, 'register.html', {'errors': []})


def logout_page(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('/login/')


def smartwatches(request):
    return render(request, 'smartwatches.html', context={'page': "SmartWatches"})


def phones(request):
    return render(request, "phones.html", context={'page': "Phones"})


def laptops(request):
    return render(request, "laptops.html", context={'page': "Laptops"})


def buy_smartwatch(request, smartwatch_slug):
    smartwatch = get_object_or_404(Device, slug=smartwatch_slug)
    buy_url = reverse('buy_smartwatch', kwargs={'smartwatch_slug': smartwatch.slug})
    return render(request, 'buy_smartwatch.html', context={'page': f"Buy {smartwatch}", 'smartwatch': smartwatch, 'buy_url': buy_url})


def buy_phone(request, phone_slug):
    phone = get_object_or_404(Device, slug=phone_slug)
    buy_url = reverse('buy_phone', kwargs={'phone_slug': phone.slug})
    return render(request, 'buy_phone.html', context={'page': f"Buy {phone}", 'phone': phone, 'buy_url': buy_url})


def buy_laptop(request, laptop_slug):
    logger.debug(f"Request received for laptop slug: {laptop_slug}")
    laptop = get_object_or_404(Device, slug=laptop_slug)
    buy_url = reverse('buy_laptop', kwargs={'laptop_slug': laptop.slug})
    return render(request, 'buy_laptop.html', context={'page': f'Buy {laptop}', 'laptop': laptop, 'buy_url': buy_url})


def rent_phone(request, phone_slug):
    phone = get_object_or_404(Device, slug=phone_slug)
    buy_url = reverse('rent_phone', kwargs={'phone_slug': phone.slug})
    return render(request, 'rent_phone.html', context={'page': f"Rent {phone}", 'phone': phone, 'buy_url': buy_url})


def whyrent(request):
    return render(request, 'whyrent.html', context={'page': "Why Rent"})


def rent_laptop(request, laptop_slug):
    laptop = get_object_or_404(Device, slug=laptop_slug)
    rent_url = reverse('rent_laptop', kwargs={'laptop_slug': laptop.slug})
    return render(request, 'rent_laptop.html', context={'page': f'Rent {laptop}', 'laptop': laptop, 'rent_url': rent_url})


@login_required
def user_profile(request):
    user = request.user
    # Ensure the user has a profile
    profile, created = Profile.objects.get_or_create(user=user)

    if request.method == "POST":
        user.first_name = request.POST.get("first_name", user.first_name)
        user.last_name = request.POST.get("last_name", user.last_name)
        user.email = request.POST.get("email", user.email)
        profile.phone_number = request.POST.get("phone_number", profile.phone_number)

        user.save()
        profile.save()

        return redirect("user_profile")

    return render(request, "user.html", {"user": user})


@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()


def disclaimer(request):
    return render(request, 'disclaimer.html', context={'page': "Disclaimer !"})


def checkout_laptop(request, laptop_slug):
    laptop = get_object_or_404(Device, slug=laptop_slug)
    return render(request, 'checkout_laptop.html', {
        'page': f'Buy {laptop.name}',
        'laptop': laptop,
    })


def checkout_phone(request, phone_slug):
    phone = get_object_or_404(Device, slug=phone_slug)
    return render(request, 'checkout_phone.html', {
        'page': f'Buy {phone.name}',
        'phone': phone,
    })


def checkout_smartwatch(request, smartwatch_slug):
    smartwatch = get_object_or_404(Device, slug=smartwatch_slug)
    return render(request, 'checkout_smartwatch.html', {
        'page': f'Buy {smartwatch.name}',
        'smartwatch': smartwatch,
    })


def update_profile(request):
    if request.method == 'POST':
        user = request.user
        old_password = request.POST.get('old_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')

        # Validate old password
        if not check_password(old_password, user.password):
            messages.error(request, 'Old password is incorrect.')
            print("Error: Old password is incorrect.")  # Debugging
            return redirect('user_profile')

        # Validate new passwords
        if new_password != confirm_password:
            messages.error(request, 'New passwords do not match.')
            print("Error: New passwords do not match.")  # Debugging
            return redirect('user_profile')

        # Update user password
        user.set_password(new_password)
        user.save()

        messages.success(request, 'Your changes have been saved successfully!')
        print("Success: Changes saved.")  # Debugging
        return redirect('user_profile')

    return render(request, 'user_profile.html')


def terms_and_conditions(request):
    return render(request, 'tc.html', context={'page': 'Terms and Condition '})


def payment_phone(request, phone_slug):
    phone = get_object_or_404(Device, slug=phone_slug)
    return render(request, 'payment_phone.html', context={'page': f'Buy {phone.name}',
                                                    'phone': phone,})


def payment_laptop(request, laptop_slug):
    laptop = get_object_or_404(Device, slug=laptop_slug)
    return render(request, 'payment_laptop.html', {
        'page': f'Buy {laptop.name}',
        'laptop': laptop,
    })


def payment_smartwatch(request, smartwatch_slug):
    smartwatch = get_object_or_404(Device, slug=smartwatch_slug)
    return render(request, 'payment_smartwatch.html', {
        'page': f'Buy {smartwatch.name}',
        'smartwatch': smartwatch,
    })


def payrent_laptop(request, laptop_slug):
    # Fetch the laptop object based on the slug
    laptop = get_object_or_404(Device, slug=laptop_slug)
    
    # Get the number of days from the query parameters
    days_str = request.GET.get('days', None)
    
    # Validate the 'days' parameter
    if not days_str or not days_str.isdigit():
        messages.error(request, "Please select a valid number of days.")
        return redirect('rent_laptop', laptop_slug=laptop_slug)
    
    try:
        days = int(days_str)  # Convert to integer
        if days <= 0:  # Ensure days is positive
            raise ValueError
    except ValueError:
        messages.error(request, "Invalid number of days selected.")
        return redirect('rent_laptop', laptop_slug=laptop_slug)
    
    # Calculate the total rent price
    total_rent_price = laptop.daily_rent_price * days
    
    # Render the payment page with the laptop details and total rent price
    return render(request, 'payrent_laptop.html', {
        'laptop': laptop,
        'days': days,
        'total_rent_price': total_rent_price
    })


def payrent_phone(request, phone_slug):
    # Fetch the laptop object based on the slug
    phone = get_object_or_404(Device, slug=phone_slug)
    
    # Get the number of days from the query parameters
    days_str = request.GET.get('days', None)
    
    # Validate the 'days' parameter
    if not days_str or not days_str.isdigit():
        messages.error(request, "Please select a valid number of days.")
        return redirect('rent_phone', phone_slug=phone_slug)
    
    try:
        days = int(days_str)  # Convert to integer
        if days <= 0:  # Ensure days is positive
            raise ValueError
    except ValueError:
        messages.error(request, "Invalid number of days selected.")
        return redirect('rent_phone', phone_slug=phone_slug)
    
    # Calculate the total rent price
    total_rent_price = phone.daily_rent_price * days
    
    # Render the payment page with the laptop details and total rent price
    return render(request, 'payrent_phone.html', {
        'phone': phone,
        'days': days,
        'total_rent_price': total_rent_price
    })


def about(request):
    return render(request, 'about.html', {
        'page': "About"
    })


def feedback_view(request):
    if request.method == "POST":
        form = FeedbackForm(request.POST)
        if form.is_valid():
            experience = form.cleaned_data.get("experience_rating") or form.cleaned_data.get("experience_text")
            bug_report = form.cleaned_data.get("bug_report")
            bug_details = form.cleaned_data.get("bug_details") if bug_report == "Yes" else "No bugs reported"
            theme = form.cleaned_data.get("theme_rating") or form.cleaned_data.get("theme_text")
            ideas = form.cleaned_data.get("ideas")

            email_body = f"""
            Experience: {experience}
            Bug Report: {bug_report}
            Bug Details: {bug_details}
            Theme Feedback: {theme}
            Suggestions: {ideas}
            """

            try:
                send_mail(
                    subject="New Feedback Submission",
                    message=email_body,
                    from_email=settings.EMAIL_HOST_USER,  # Now this will work
                    recipient_list=[settings.EMAIL_HOST_USER],
                    fail_silently=False,
                )
                return JsonResponse({'success': True})
            except Exception as e:
                return JsonResponse({'success': False, 'error': str(e)})
    else:
        form = FeedbackForm()
    return render(request, "feedback.html", {"form": form})
