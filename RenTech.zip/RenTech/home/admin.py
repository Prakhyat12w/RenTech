from django.contrib import admin
from .models import Device, Order, Payment, Review, RentalHistory, ShippingAddress
# Register your models here.
admin.site.register(Device)
admin.site.register(Order)
admin.site.register(Payment)
admin.site.register(Review)
admin.site.register(RentalHistory)
admin.site.register(ShippingAddress)
